package com.company;

import org.apache.juneau.annotation.BeanConstructor;

public class Name_desc {
    private String Name_desc;

    public String getName_desc() {
        return Name_desc;
    }

    public void setName_desc(String name_desc) {
        Name_desc = name_desc;
    }
    @BeanConstructor(properties = "names")
    public Name_desc(String name_desc) {
        Name_desc = name_desc;
    }

    @Override
    public String toString() {
        return Name_desc ;
    }
}
