package com.company;

import org.apache.juneau.annotation.BeanConstructor;

public class Date_desc {
    private String date;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @BeanConstructor(properties = "date")
    public Date_desc(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return  date ;
    }
}
