package com.company;

import org.apache.juneau.annotation.BeanConstructor;

public class CombinedList {
    private String cname;
    private String cnameDate;
    private String description;

    public String getCnameDate() {
        return cnameDate;
    }

    public void setCnameDate(String cnameDate) {
        this.cnameDate = cnameDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }
    @BeanConstructor(properties = "cname,cnameDate,description")
    public CombinedList(String cname, String cnameDate, String description) {
        this.cname = cname;
        this.cnameDate = cnameDate;
        this.description = description;
    }

    @Override
    public String toString() {
        return "CombinedList{" +
                "cnameqqq='" + cname + '\'' +
                ", cnameDate='" + cnameDate + '\'' +
                ", description='" + description + '\'' +
                '}';
    }
}
