package com.company;

import org.apache.juneau.serializer.SerializeException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.apache.juneau.json.JsonSerializer;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) throws SerializeException, IOException {

        ArrayList<Name_desc> name_date_list = new ArrayList<>();
        ArrayList<Desc_Product> desc_list = new ArrayList<>();
        ArrayList<Date_desc> date_list = new ArrayList<>();
        FileWriter fileWriter = new FileWriter("F:\\selenium_test\\src\\com\\company\\json_file1.json");

        System.setProperty("webdriver.chrome.driver","F:\\browser driver\\chromedriver.exe");
        WebDriver driver1 = new ChromeDriver();
        driver1.get("https://www.mia.org.my/v2/surveillance/disciplinary/decisions.aspx");


        for(int i = 0 ;i<8;i++){
            for (int j =0;j<10;j++ ){
                try {
                    List<WebElement> d1 = driver1.findElements(By.cssSelector("a[id*='PageContents_LVDecisions_ctrl']"));
                    WebElement webElementd1 = d1.get(j);
                    webElementd1.click();

                    List<WebElement> d3 = driver1.findElements(By.cssSelector("article.br5.bgaliceblue.alignjustify"));
                    WebElement webElementd3 = d3.get(0);


                    Desc_Product desc_product = new Desc_Product(webElementd3.getText());
                    desc_list.add(desc_product);
                    driver1.navigate().back();
                } catch (IndexOutOfBoundsException e) {
                }
            }
            List<WebElement> ed1 = driver1.findElements(By.cssSelector("input.dbutton"));
            WebElement webElemented1 = ed1.get(4);
            webElemented1.click();
        }

        WebDriver driver2 = new ChromeDriver();
        driver2.get("https://www.mia.org.my/v2/surveillance/disciplinary/decisions.aspx");
        for (int i =0 ;i<8;i++){
            List<WebElement> e1 = driver2.findElements(By.cssSelector("td.widthtd75"));
            List<WebElement> e3 = driver2.findElements(By.cssSelector("span[id*='PageContents_LVDecisions_ctrl']"));
            for(int j = 0 ;j<10;j++){
                try {
                    WebElement webElement1 = e1.get(j);
                    WebElement webElement3 = e3.get(j);
                    Name_desc name_desc = new Name_desc(webElement1.getText());
                    Date_desc date_desc = new Date_desc(webElement3.getText());

                        name_date_list.add(name_desc);
                        date_list.add(date_desc);
                }catch (Exception e){}
            }
            List<WebElement> e2 = driver2.findElements(By.cssSelector("input.dbutton"));
            WebElement webElement = e2.get(4);
            webElement.click();
        }
        PrintWriter out = new PrintWriter(fileWriter);
        for(int i =0; i<100;i++){
            CombinedList combinedList = new CombinedList(String.valueOf(name_date_list.get(i)),String.valueOf(date_list.get(i)),String.valueOf(desc_list.get(i)));
            JsonSerializer jsonSerializer = JsonSerializer.DEFAULT_READABLE;
            String name_date =  jsonSerializer.serialize(combinedList);

            out.append(name_date);
            out.flush();

            try {
                System.out.println(name_date);
            } catch (IndexOutOfBoundsException e) {

            }
        }
    }
}
