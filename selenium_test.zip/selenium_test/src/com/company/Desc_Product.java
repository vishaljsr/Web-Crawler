package com.company;

import org.apache.juneau.annotation.BeanConstructor;

public class Desc_Product {

    private String description;

    @BeanConstructor(properties = "description")
    public Desc_Product(String description) {

        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }



    @Override
    public String toString() {
        return  description;
    }
}
